package org.mich.test.springboot.app.services;

import org.mich.test.springboot.app.models.Cuenta;

import java.math.BigDecimal;

public interface CuentaService {

    Cuenta findById(Long id);

    int revisarTotalTransferencias(Long bancoID);

    BigDecimal revisarSaldo(Long cuentaID);

    void transferir(Long numCuentaOrigen, Long numeroCuentaDestino,
                    BigDecimal monto, Long bancoID);

}
