package org.mich.test.springboot.app.controllers;

import org.mich.test.springboot.app.models.Cuenta;
import org.mich.test.springboot.app.models.TransaccionDTO;
import org.mich.test.springboot.app.services.CuentaService;
import org.springframework.beans.factory.annotation.Autowired;
import static org.springframework.http.HttpStatus.*;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/cuentas")
public class CuentaController {

    @Autowired
    CuentaService cuentaService;

    //Devolvemos un objeto Cuenta como JSON
    @GetMapping("/{id}") //{id} -> las llaves nos dicen que es un argumento variable
    @ResponseStatus(OK)
    public Cuenta detalle(@PathVariable(name = "id") long id){ //Por defecto toma el nombre id del parametro, sino podemos especificarlo
        return cuentaService.findById(id);
    }

    //Método transferir - enviamos los datos desde el cuerpo del request (JSON) y no desde la ruta
    @PostMapping("/transferir")
    public ResponseEntity<?> transferir(@RequestBody TransaccionDTO dto){ //ResponseEntity<?> -> devolvemos algo a traves de un JSON, donde el tipo es varaible, pero en nuestro caso va a ser un Map
        //Para poder devolver esta informacion, creamos un objeto DTO (Data Transfer Object) en models
        cuentaService.transferir(dto.getCuentaOrigenID(),
                dto.getCuentaDestinoID(),
                dto.getMonto(), dto.getBancoID());

        //Devolvemos el response entity
        Map<String, Object> response = new HashMap<>();
        response.put("date", LocalDate.now().toString());
        response.put("status", "OK");
        response.put("mensaje", "Transferencia realizada con exito!");
        response.put("transaccion", dto);

        return ResponseEntity.ok(response);
    }

}
