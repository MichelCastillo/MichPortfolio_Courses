INSERT INTO cuentas (persona, saldo) VALUES ('Mich', 1000)
INSERT INTO cuentas (persona, saldo) VALUES ('Michel', 2000)
INSERT INTO bancos (nombre, total_transferencias) VALUES ('Banco Santander', 0)