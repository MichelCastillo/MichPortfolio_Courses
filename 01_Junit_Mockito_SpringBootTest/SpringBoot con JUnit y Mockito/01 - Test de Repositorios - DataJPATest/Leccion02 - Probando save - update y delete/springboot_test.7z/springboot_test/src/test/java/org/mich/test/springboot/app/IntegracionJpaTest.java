package org.mich.test.springboot.app;

import org.junit.jupiter.api.Test;
import org.mich.test.springboot.app.models.Cuenta;
import org.mich.test.springboot.app.repositories.CuentaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.math.BigDecimal;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@DataJpaTest
public class IntegracionJpaTest {

    @Autowired
    CuentaRepositorio cuentaRepositorio;

    @Test
    void testFindById() {
        Optional<Cuenta> cuenta = cuentaRepositorio.findById(1L);

        assertTrue(cuenta.isPresent());
        assertEquals("Mich", cuenta.orElseThrow().getPersona());
    }

    @Test
    void testFindByPersona() {
        Optional<Cuenta> cuenta = cuentaRepositorio.findByPersonaMetodo("Mich");

        assertTrue(cuenta.isPresent());
        assertEquals("Mich", cuenta.orElseThrow().getPersona());
        assertEquals("1000.00", cuenta.orElseThrow().getSaldo().toPlainString());
    }

    @Test
    void testFindByPersonaThrowException() {
        //Probamos que ante un nombre de persona que no existe, nos devuelva una excepcion
        Optional<Cuenta> cuenta = cuentaRepositorio.findByPersonaMetodo("Nacho"); //No existe

        assertThrows(NoSuchElementException.class, () -> {
            cuenta.orElseThrow(); //Con esto, al no estar presente, va a saltar la exepcion
        });

        //Forma resumida - Nombre/Metodo de referencia
        assertThrows(NoSuchElementException.class, cuenta::orElseThrow);
        assertFalse(cuenta.isPresent());
    }

    @Test
    void testFindAll() {
        //Probamos que nos devuelva datos el findAll, y que estos sean 2
        List<Cuenta> cuentas = cuentaRepositorio.findAll();

        assertFalse(cuentas.isEmpty());
        assertEquals(2, cuentas.size());
    }

    //Probando el SAVE
    @Test
    void testSave() {
        //Given
        Cuenta cuentaPepe = new Cuenta(null, "Pepe", new BigDecimal(3000));
        //Cuenta save = cuentaRepositorio.save(cuentaPepe);

        //When
        Cuenta cuenta = cuentaRepositorio.save(cuentaPepe);
        //Cuenta cuenta = cuentaRepositorio.findByPersonaMetodo("Pepe").orElseThrow();
        //Cuenta cuenta = cuentaRepositorio.findById(save.getId()).orElseThrow();

        //Then
        assertEquals("Pepe", cuenta.getPersona());
        assertEquals("3000", cuenta.getSaldo().toPlainString());
        assertEquals(3, cuenta.getId());
    }

    //Probando el UPDATE
    @Test
    void testUpdate() {
        //Given
        Cuenta cuentaPepe = new Cuenta(null, "Pepe", new BigDecimal(3000));

        //When
        Cuenta cuenta = cuentaRepositorio.save(cuentaPepe);

        //Then
        assertEquals("Pepe", cuenta.getPersona());
        assertEquals("3000", cuenta.getSaldo().toPlainString());
        assertEquals(3, cuenta.getId());

        //Probamos modificaciones
        //When
        cuenta.setSaldo(new BigDecimal(3800));
        Cuenta cuentaActualizada = cuentaRepositorio.save(cuenta);

        //Then
        assertEquals("Pepe", cuentaActualizada.getPersona());
        assertEquals("3800", cuentaActualizada.getSaldo().toPlainString());
    }

    //Probando el DELETE
    @Test
    void testDelete() {
        //Given
        Cuenta cuenta = cuentaRepositorio.findById(1L).orElseThrow();
        assertEquals("Mich", cuenta.getPersona());

        //When
        cuentaRepositorio.delete(cuenta);

        //Then
        assertThrows(NoSuchElementException.class, () -> {
            cuentaRepositorio.findByPersona("Mich").orElseThrow();
        });
        assertEquals(1, cuentaRepositorio.findAll().size());
    }
}
