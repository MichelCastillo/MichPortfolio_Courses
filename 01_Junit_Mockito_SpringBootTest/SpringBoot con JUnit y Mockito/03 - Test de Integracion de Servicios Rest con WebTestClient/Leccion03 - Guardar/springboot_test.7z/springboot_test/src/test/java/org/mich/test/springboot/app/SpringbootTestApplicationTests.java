package org.mich.test.springboot.app;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mich.test.springboot.app.exceptions.DineroInsuficienteException;
import org.mich.test.springboot.app.models.Banco;
import org.mich.test.springboot.app.models.Cuenta;
import static org.mich.test.springboot.app.Datos.*;
import org.mich.test.springboot.app.repositories.BancoRepositorio;
import org.mich.test.springboot.app.repositories.CuentaRepositorio;
import org.mich.test.springboot.app.services.CuentaService;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

@SpringBootTest
class SpringbootTestApplicationTests {

	@MockBean
	CuentaRepositorio cuentaRepositorio;

	@MockBean
	BancoRepositorio bancoRepositorio;

	@Autowired
	CuentaService service;

	@Test
	void contextLoads() {
		when(cuentaRepositorio.findById(1L)).thenReturn(crearCuenta001());
		when(cuentaRepositorio.findById(2L)).thenReturn(crearCuenta002());
		when(bancoRepositorio.findById(1L)).thenReturn((crearBanco()));

		BigDecimal saldoOrigen = service.revisarSaldo(1L);
		BigDecimal saldoDestino = service.revisarSaldo(2L);

		assertEquals("1000", saldoOrigen.toPlainString());
		assertEquals("2000", saldoDestino.toPlainString());

		service.transferir(1L, 2L, new BigDecimal(100), 1L);

		saldoOrigen = service.revisarSaldo(1L);
		saldoDestino = service.revisarSaldo(2L);

		assertEquals("900", saldoOrigen.toPlainString());
		assertEquals("2100", saldoDestino.toPlainString());

		int total = service.revisarTotalTransferencias(1L);
		assertEquals(1, total);

		verify(cuentaRepositorio, times(3)).findById(1L);
		verify(cuentaRepositorio, times(3)).findById(2L);
		verify(cuentaRepositorio, times(2)).save(any(Cuenta.class));

		verify(bancoRepositorio, times(2)).findById(1L);
		verify(bancoRepositorio, times(1)).save(any(Banco.class));

		verify(cuentaRepositorio, times(6)).findById(anyLong());
	}

	@Test
	void contextLoads2() {
		when(cuentaRepositorio.findById(1L)).thenReturn(crearCuenta001());
		when(cuentaRepositorio.findById(2L)).thenReturn(crearCuenta002());
		when(bancoRepositorio.findById(1L)).thenReturn((crearBanco()));

		BigDecimal saldoOrigen = service.revisarSaldo(1L);
		BigDecimal saldoDestino = service.revisarSaldo(2L);

		assertEquals("1000", saldoOrigen.toPlainString());
		assertEquals("2000", saldoDestino.toPlainString());

		assertThrows(DineroInsuficienteException.class, () -> {
			service.transferir(1L, 2L, new BigDecimal(1200), 1L);

		});

		saldoOrigen = service.revisarSaldo(1L);
		saldoDestino = service.revisarSaldo(2L);

		assertEquals("1000", saldoOrigen.toPlainString());
		assertEquals("2000", saldoDestino.toPlainString());

		int total = service.revisarTotalTransferencias(1L);
		assertEquals(0, total);

		verify(cuentaRepositorio, times(3)).findById(1L);
		verify(cuentaRepositorio, times(2)).findById(2L);
		verify(cuentaRepositorio, never()).save(any(Cuenta.class));

		verify(bancoRepositorio, times(1)).findById(1L);
		verify(bancoRepositorio, never()).save(any(Banco.class));

		verify(cuentaRepositorio, times(5)).findById(anyLong());
		verify(cuentaRepositorio, never()).findAll();
	}

	@Test
	void contextLoad3() {
		when(cuentaRepositorio.findById(1L)).thenReturn(crearCuenta001());

		Cuenta cuenta1 = service.findById(1L);
		Cuenta cuenta2 = service.findById(1L);

		assertSame(cuenta1, cuenta2);

		assertTrue(cuenta1 == cuenta2);

		assertEquals("Mich", cuenta1.getPersona());
		assertEquals("Mich", cuenta2.getPersona());

		verify(cuentaRepositorio, times(2)).findById(1L);
	}

	@Test
	void testFindAll() {
		// Given
		List<Cuenta> datos = Arrays.asList(crearCuenta001().orElseThrow(),
				crearCuenta002().orElseThrow());
		when(cuentaRepositorio.findAll()).thenReturn(datos);

		// When
		List<Cuenta> cuentas = service.findaAll();

		// Then
		assertFalse(cuentas.isEmpty());
		assertEquals(2, cuentas.size());
		assertTrue(cuentas.contains(crearCuenta002().orElseThrow())); //Compara con cada uno de los elementos con el método equals

		verify(cuentaRepositorio).findAll();
	}

	@Test
	void testSave() {
		// Given
		Cuenta cuentaSave = new Cuenta(null, "Save", new BigDecimal(4000));
		when(cuentaRepositorio.save(any())).then(invocation -> {
			Cuenta c = invocation.getArgument(0);
			c.setId(3L);
			return c;
		});

		// When
		Cuenta cuenta = service.save(cuentaSave);

		// Then
		assertEquals("Save", cuenta.getPersona());
		assertEquals(3, cuenta.getId());
		assertEquals("4000", cuenta.getSaldo().toPlainString());

		verify(cuentaRepositorio).save(any());
	}
}
