package org.mich.test.springboot.app;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mich.test.springboot.app.exceptions.DineroInsuficienteException;
import org.mich.test.springboot.app.models.Banco;
import org.mich.test.springboot.app.models.Cuenta;
import static org.mich.test.springboot.app.Datos.*;
import org.mich.test.springboot.app.repositories.BancoRepositorio;
import org.mich.test.springboot.app.repositories.CuentaRepositorio;
import org.mich.test.springboot.app.services.CuentaService;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.mich.test.springboot.app.services.impl.CuentaServiceImpl;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;

@SpringBootTest
class SpringbootTestApplicationTests {

	CuentaRepositorio cuentaRepositorio;
	BancoRepositorio bancoRepositorio;

	CuentaService service;

	@BeforeEach
	void setUp() {
		cuentaRepositorio = mock(CuentaRepositorio.class);
		bancoRepositorio = mock(BancoRepositorio.class);
		service = new CuentaServiceImpl(cuentaRepositorio, bancoRepositorio);

		//Primera forma de solucionar el problema de concurrencia
		//Datos.crearCuenta001().setSaldo(new BigDecimal(1000));
		//Datos.crearCuenta002().setSaldo(new BigDecimal(2000));
		//Datos.crearBanco().setTotalTransferencia(0);
	}

	@Test
	void contextLoads() {
		when(cuentaRepositorio.findById(1L)).thenReturn(crearCuenta001());
		when(cuentaRepositorio.findById(2L)).thenReturn(crearCuenta002());
		when(bancoRepositorio.findById(1L)).thenReturn((crearBanco()));

		BigDecimal saldoOrigen = service.revisarSaldo(1L);
		BigDecimal saldoDestino = service.revisarSaldo(2L);

		assertEquals("1000", saldoOrigen.toPlainString());
		assertEquals("2000", saldoDestino.toPlainString());

		service.transferir(1L, 2L, new BigDecimal(100), 1L);

		saldoOrigen = service.revisarSaldo(1L);
		saldoDestino = service.revisarSaldo(2L);

		assertEquals("900", saldoOrigen.toPlainString());
		assertEquals("2100", saldoDestino.toPlainString());

		int total = service.revisarTotalTransferencias(1L);
		assertEquals(1, total);

		//Métodos verify - Cuenta
		verify(cuentaRepositorio, times(3)).findById(1L);
		verify(cuentaRepositorio, times(3)).findById(2L);
		verify(cuentaRepositorio, times(2)).update(any(Cuenta.class));

		//Métodos verify - Banco
		verify(bancoRepositorio, times(2)).findById(1L);
		verify(bancoRepositorio, times(1)).update(any(Banco.class));

		verify(cuentaRepositorio, times(6)).findById(anyLong());
	}

	//Leccion 02: Escribiendo test assertThrow para afirmar que la excepcion lanzada sea correcta
	//Caso en el que transferimos una cantidad superior a la permitida para una cuenta
	//El problema con este diseño es que ambos metodos estan modificando los mismos datos, cuando deberian ser independientes.
	// Para solucionar esto existen dos opciones:
	//	1- Reiniciar los saldos de las cuentas cada vez que se ejecute un metodo test, en el beforeEach
	//	2- En lugar de usar constantes, usamos métodos estáticos
	@Test
	void contextLoads2() {
		when(cuentaRepositorio.findById(1L)).thenReturn(crearCuenta001());
		when(cuentaRepositorio.findById(2L)).thenReturn(crearCuenta002());
		when(bancoRepositorio.findById(1L)).thenReturn((crearBanco()));

		BigDecimal saldoOrigen = service.revisarSaldo(1L);
		BigDecimal saldoDestino = service.revisarSaldo(2L);

		assertEquals("1000", saldoOrigen.toPlainString());
		assertEquals("2000", saldoDestino.toPlainString());

		assertThrows(DineroInsuficienteException.class, () -> {
			service.transferir(1L, 2L, new BigDecimal(1200), 1L);

		});

		saldoOrigen = service.revisarSaldo(1L);
		saldoDestino = service.revisarSaldo(2L);

		assertEquals("1000", saldoOrigen.toPlainString());
		assertEquals("2000", saldoDestino.toPlainString());

		int total = service.revisarTotalTransferencias(1L);
		assertEquals(0, total);

		//Métodos verify - Cuenta
		verify(cuentaRepositorio, times(3)).findById(1L);
		//Como se lanza la excepción, no se ejecuta el findById de la segunda cuenta para hacerle el credito
		verify(cuentaRepositorio, times(2)).findById(2L);
		verify(cuentaRepositorio, never()).update(any(Cuenta.class));

		//Métodos verify - Banco
		verify(bancoRepositorio, times(1)).findById(1L);
		verify(bancoRepositorio, never()).update(any(Banco.class));

		verify(cuentaRepositorio, times(5)).findById(anyLong());
		verify(cuentaRepositorio, never()).findAll();
	}

	@Test
	void contextLoad3() {
		when(cuentaRepositorio.findById(1L)).thenReturn(crearCuenta001());

		Cuenta cuenta1 = service.findById(1L);
		Cuenta cuenta2 = service.findById(1L);

		//Comprobamos que cuenta1, sea la misma que cuenta2
		assertSame(cuenta1, cuenta2);

		//Otra forma
		assertTrue(cuenta1 == cuenta2);

		assertEquals("Andres", cuenta1.getPersona());
		assertEquals("Andres", cuenta2.getPersona());

		verify(cuentaRepositorio, times(2)).findById(1L);
	}
}
