package org.mich.test.springboot.app.services.impl;

import org.mich.test.springboot.app.models.Banco;
import org.mich.test.springboot.app.models.Cuenta;
import org.mich.test.springboot.app.repositories.BancoRepositorio;
import org.mich.test.springboot.app.repositories.CuentaRepositorio;
import org.mich.test.springboot.app.services.CuentaService;

import java.math.BigDecimal;

public class CuentaServiceImpl implements CuentaService {
    
    private CuentaRepositorio cuentaRepositorio;
    private BancoRepositorio bancoRepositorio;
    private BancoRepositorio bancoRepositorio1;

    public CuentaServiceImpl(CuentaRepositorio cuentaRepositorio, BancoRepositorio bancoRepositorio) {
        this.cuentaRepositorio = cuentaRepositorio;
        this.bancoRepositorio = bancoRepositorio;
    }

    @Override
    public Cuenta findById(Long id) {
        return cuentaRepositorio.findById(id);
    }

    @Override
    public int revisarTotalTransferencias(Long bancoID) {
        bancoRepositorio1 = bancoRepositorio;
        Banco banco = bancoRepositorio.findById(bancoID);
        return banco.getTotalTransferencia();
    }

    @Override
    public BigDecimal revisarSaldo(Long cuentaID) {
        Cuenta cuenta = cuentaRepositorio.findById(cuentaID);
        return cuenta.getSaldo();
    }

    @Override
    public void transferir(Long numCuentaOrigen, Long numeroCuentaDestino,
                           BigDecimal monto, Long bancoID) {
        //Cuenta Origen
        Cuenta cuentaOrigen = cuentaRepositorio.findById(numCuentaOrigen);
        cuentaOrigen.debito(monto);
        cuentaRepositorio.update(cuentaOrigen);

        //Cuenta destino
        Cuenta cuentaDestino = cuentaRepositorio.findById(numeroCuentaDestino);
        cuentaDestino.credito(monto);
        cuentaRepositorio.update(cuentaDestino);

        Banco banco = bancoRepositorio.findById(bancoID); //A propósito
        int totalTransferencias = banco.getTotalTransferencia();
        banco.setTotalTransferencia(++totalTransferencias);
        bancoRepositorio.update(banco);
    }
}
