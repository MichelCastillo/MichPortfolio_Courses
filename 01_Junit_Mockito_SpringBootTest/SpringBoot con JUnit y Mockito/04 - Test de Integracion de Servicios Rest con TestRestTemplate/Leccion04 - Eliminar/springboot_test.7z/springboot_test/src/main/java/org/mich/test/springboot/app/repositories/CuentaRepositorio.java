package org.mich.test.springboot.app.repositories;

import org.mich.test.springboot.app.models.Cuenta;
import org.springframework.data.jpa.repository.*;

import java.util.List;
import java.util.Optional;

public interface CuentaRepositorio extends JpaRepository<Cuenta, Long> {

    //Busqueda mediente nombre del metodo
    Optional<Cuenta> findByPersona(String persona);

    //Busqueda mediante Query
    @Query("select c from Cuenta c where c.persona=?1")
    Optional<Cuenta> findByPersonaMetodo(String persona);

    //Todos estos métodos ya vienen implementados desde JpaRepository
    //List<Cuenta> findAll();
    //Cuenta findById(Long id);
    //void update(Cuenta cuenta);
}
