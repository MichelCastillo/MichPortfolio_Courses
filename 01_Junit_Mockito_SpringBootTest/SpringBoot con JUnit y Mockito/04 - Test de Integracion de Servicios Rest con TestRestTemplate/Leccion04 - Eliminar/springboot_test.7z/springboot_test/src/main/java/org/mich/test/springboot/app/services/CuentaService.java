package org.mich.test.springboot.app.services;

import org.mich.test.springboot.app.models.Cuenta;

import java.math.BigDecimal;
import java.util.List;

public interface CuentaService {

    Cuenta findById(Long id);

    int revisarTotalTransferencias(Long bancoID);

    BigDecimal revisarSaldo(Long cuentaID);

    void transferir(Long numCuentaOrigen, Long numeroCuentaDestino,
                    BigDecimal monto, Long bancoID);

    //Leccion 04- Agregando los métodos listar, guardar, findAll y save
    List<Cuenta> findaAll();

    Cuenta save(Cuenta cuenta);

    //Leccion04 - Eliminar
    void deleteById(Long id);

}
