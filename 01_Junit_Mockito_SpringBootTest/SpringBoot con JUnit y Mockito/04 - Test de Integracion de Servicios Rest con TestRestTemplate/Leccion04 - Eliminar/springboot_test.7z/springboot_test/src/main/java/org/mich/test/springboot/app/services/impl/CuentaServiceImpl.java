package org.mich.test.springboot.app.services.impl;

import org.mich.test.springboot.app.models.Banco;
import org.mich.test.springboot.app.models.Cuenta;
import org.mich.test.springboot.app.repositories.BancoRepositorio;
import org.mich.test.springboot.app.repositories.CuentaRepositorio;
import org.mich.test.springboot.app.services.CuentaService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class CuentaServiceImpl implements CuentaService {

    private CuentaRepositorio cuentaRepositorio;
    private BancoRepositorio bancoRepositorio;

    public CuentaServiceImpl(CuentaRepositorio cuentaRepositorio, BancoRepositorio bancoRepositorio) {
        this.cuentaRepositorio = cuentaRepositorio;
        this.bancoRepositorio = bancoRepositorio;
    }
    //Envolvemos a cada metodo de nuestro Service como una transaccion única
    //Aclaramos que existen algunos métodos de tipo ReadOnly para aquellos que no hacen modificaciones

    @Override
    @Transactional(readOnly = true)
    public Cuenta findById(Long id) {
        return cuentaRepositorio.findById(id).orElseThrow();
    }

    @Override
    @Transactional(readOnly = true)
    public int revisarTotalTransferencias(Long bancoID) {
        Banco banco = bancoRepositorio.findById(bancoID).orElseThrow();
        return banco.getTotalTransferencias();
    }

    @Override
    @Transactional(readOnly = true)
    public BigDecimal revisarSaldo(Long cuentaID) {
        Cuenta cuenta = cuentaRepositorio.findById(cuentaID).orElseThrow();
        return cuenta.getSaldo();
    }

    @Override
    @Transactional()
    public void transferir(Long numCuentaOrigen, Long numeroCuentaDestino,
                           BigDecimal monto, Long bancoID) {
        //Cuenta Origen
        Cuenta cuentaOrigen = cuentaRepositorio.findById(numCuentaOrigen).orElseThrow();
        cuentaOrigen.debito(monto);
        cuentaRepositorio.save(cuentaOrigen);

        //Cuenta destino
        Cuenta cuentaDestino = cuentaRepositorio.findById(numeroCuentaDestino).orElseThrow();
        cuentaDestino.credito(monto);
        cuentaRepositorio.save(cuentaDestino);

        Banco banco = bancoRepositorio.findById(bancoID).orElseThrow();
        int totalTransferencias = banco.getTotalTransferencias();
        banco.setTotalTransferencias(++totalTransferencias);
        bancoRepositorio.save(banco);
    }

    @Override
    @Transactional(readOnly = true)

    public List<Cuenta> findaAll() {
        return cuentaRepositorio.findAll();
    }

    @Override
    @Transactional()
    public Cuenta save(Cuenta cuenta) {
        return cuentaRepositorio.save(cuenta);
    }

    @Override
    @Transactional
    public void deleteById(Long id) {
        cuentaRepositorio.deleteById(id);
    }
}
