package org.mich.test.springboot.app.controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.*;
import org.mich.test.springboot.app.models.Cuenta;
import org.mich.test.springboot.app.models.TransaccionDTO;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest(webEnvironment = RANDOM_PORT)
class CuentaControllerWebTestClientTest {

    @Autowired
    private WebTestClient client;

    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        this.objectMapper = new ObjectMapper();
    }

    @Test
    @Order(1)
    void testTrasnferir() throws JsonProcessingException {
        // Given
        TransaccionDTO dto = new TransaccionDTO();
        dto.setCuentaOrigenID(1L);
        dto.setCuentaDestinoID(2L);
        dto.setBancoID(1L);
        dto.setMonto(new BigDecimal(100));

        Map<String, Object> response = new HashMap<>();
        response.put("date", LocalDate.now().toString());
        response.put("status", "OK");
        response.put("mensaje", "Transferencia realizada con exito!");
        response.put("transaccion", dto);

        // When
        client.post().uri("/api/cuentas/transferir")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(dto)
                .exchange()
                // Then
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .consumeWith(respuesta -> {
                    try {
                        JsonNode json = objectMapper.readTree(respuesta.getResponseBody());
                        assertEquals("Transferencia realizada con exito!", json.path("mensaje").asText());
                        assertEquals(1, json.path("transaccion").path("cuentaOrigenID").asLong());
                        assertEquals(LocalDate.now().toString(), json.path("date").asText());
                        assertEquals("100", json.path("transaccion").path("monto").asText());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                })
                .jsonPath("$.mensaje").isNotEmpty()
                .jsonPath("$.mensaje").value(is("Transferencia realizada con exito!"))
                .jsonPath("$.mensaje").value(valor -> {
                    assertEquals("Transferencia realizada con exito!", valor);
                })
                .jsonPath("$.mensaje").isEqualTo("Transferencia realizada con exito!")
                .jsonPath("$.transaccion.cuentaOrigenID").isEqualTo(dto.getCuentaOrigenID())
                .jsonPath("$.date").isEqualTo(LocalDate.now().toString())
                .json(objectMapper.writeValueAsString(response));
    }

    //Leccion02 - Test de Integración para el método Detalle
    //Agregamos a la clase test del controlador @TestMethodOrder(MethodOrderer.OrderAnnotation.class) para ejecutar los metodos en un determinado orden
    @Test
    @Order(2)
    void testDetalle() throws JsonProcessingException {
        Cuenta cuenta = new Cuenta(1L, "Mich", new BigDecimal(900));

        client.get().uri("/api/cuentas/1").exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.persona").isEqualTo("Mich")
                .jsonPath("$.saldo").isEqualTo(900)
                .json(objectMapper.writeValueAsString(cuenta))
        ;
    }

    @Test
    @Order(3)
    void testDetalle2() {

        client.get().uri("/api/cuentas/2").exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(Cuenta.class)
                .consumeWith(response -> {
                    Cuenta cuenta = response.getResponseBody();
                    assertNotNull(cuenta);
                    assertEquals("Michel", cuenta.getPersona());
                    assertEquals("2100.00", cuenta.getSaldo().toPlainString());
                })
        ;
    }

    //Leccion03 - Test de integracion para el metodo listar
    @Test
    @Order(4)
    void testListar() {
        client.get().uri("/api/cuentas").exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$[0].persona").isEqualTo("Mich")
                .jsonPath("$[0].id").isEqualTo(1)
                .jsonPath("$[0].saldo").isEqualTo(900)
                .jsonPath("$[1].persona").isEqualTo("Michel")
                .jsonPath("$[1].id").isEqualTo(2)
                .jsonPath("$[1].saldo").isEqualTo(2100)
                .jsonPath("$").isArray()
                .jsonPath("$").value(hasSize(2))
        ;
    }

    @Test
    @Order(5)
    void testListar2() {
        client.get().uri("/api/cuentas").exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBodyList(Cuenta.class)
                .consumeWith(response -> {
                    List<Cuenta> cuentas = response.getResponseBody();
                    assertNotNull(cuentas);
                    assertEquals(2, cuentas.size());
                    assertEquals(1, cuentas.get(0).getId());
                    assertEquals("Mich", cuentas.get(0).getPersona());
                    assertEquals("900.0", cuentas.get(0).getSaldo().toPlainString());
                    assertEquals(2, cuentas.get(1).getId());
                    assertEquals("Michel", cuentas.get(1).getPersona());
                    assertEquals("2100.0", cuentas.get(1).getSaldo().toPlainString());
                })
                .hasSize(2)
                .value(hasSize(2))
        ;
    }

    @Test
    @Order(6)
    void testGuardar() {
        // Given
        Cuenta cuenta = new Cuenta(null, "Pepe", new BigDecimal(3000));

        client.post().uri("/api/cuentas")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(cuenta) //Este es el objeto que queremos devolver
                .exchange()//Acá se ejecuta el post, y x ende, se guarda la cuenta que creamos arriba
                .expectStatus().isCreated()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody() //Tipo byte
                .jsonPath("$.id").isEqualTo(3)
                .jsonPath("$.persona").isEqualTo("Pepe")
                .jsonPath("$.persona").value(is("Pepe"))
                .jsonPath("$.saldo").isEqualTo(3000)
        ;
    }

    @Test
    @Order(7)
    void testGuardar2() {
        // Given
        Cuenta cuenta = new Cuenta(null, "Pepa", new BigDecimal(3500));

        // When
        client.post().uri("/api/cuentas")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(cuenta) //Este es el objeto que queremos devolver
                .exchange()//Acá se ejecuta el post, y x ende, se guarda la cuenta que creamos arriba
                // Then
                .expectStatus().isCreated()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(Cuenta.class) //Tipo Cuenta
                .consumeWith(response -> {
                    Cuenta c = response.getResponseBody();
                    assertNotNull(c);
                    assertEquals(4, c.getId());
                    assertEquals("Pepa", c.getPersona());
                    assertEquals("3500", c.getSaldo().toPlainString());
                })
        ;
    }

    //Leccion 04: Creando los test de integracion del eliminar
    @Test
    @Order(8)
    @Disabled
    void testEliminar() {
        //Validemos el tamaño de la lista antes de eliminar
        client.get().uri("/api/cuentas").exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBodyList(Cuenta.class)
                .hasSize(4)
        ;

        //Eliminamos a Pepe con el ID 3
        client.delete().uri("/api/cuentas/3").exchange()//Como no estamos enviando nada en el request, obviamos el body y el contenttype
                .expectStatus().isNoContent()
                .expectBody().isEmpty() //Chequeamos que el body esté vacio.
        ;

        // Chequeamos que ahora el tamaño de la lista sea de 3
        client.get().uri("/api/cuentas").exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBodyList(Cuenta.class)
                .hasSize(3)
        ;

        // Chequeamos el detalle - si buscamos el 3, verificamos que recibamos un 500
        client.get().uri("/api/cuentas/3").exchange()
                .expectStatus().is5xxServerError();
        //Esto se debe a que si buscamos el elemento 3, al no existir, nos tira un NoSuchElementException, lo que el mensaje HTTP nos devuelve ese 500
    }

    @Test
    @Order(9)
    void testEliminarNotFound() {
        //Validemos el tamaño de la lista antes de eliminar
        client.get().uri("/api/cuentas").exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBodyList(Cuenta.class)
                .hasSize(4)
        ;

        //Eliminamos a Pepe con el ID 3
        client.delete().uri("/api/cuentas/3").exchange()//Como no estamos enviando nada en el request, obviamos el body y el contenttype
                .expectStatus().isNoContent()
                .expectBody().isEmpty() //Chequeamos que el body esté vacio.
        ;

        // Chequeamos que ahora el tamaño de la lista sea de 3
        client.get().uri("/api/cuentas").exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBodyList(Cuenta.class)
                .hasSize(3)
        ;

        // Chequeamos el detalle - si buscamos el 3, verificamos que recibamos un 500
        client.get().uri("/api/cuentas/3").exchange()
                .expectStatus().isNotFound()
                .expectBody().isEmpty()
        ;
    }
}